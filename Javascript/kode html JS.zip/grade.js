let score = 80;

if (score >= 90) {
    console.log("Grade: A");
    console.log("Very Good");

} else if (score >= 80 && score < 90) {
    console.log("Grade: B");
    console.log("Very Good");
    
} else if (score >= 70 && score < 80) {
    console.log("Grade: C");
    console.log("Enough");

} else if  (score >= 60 && score < 70) {
    console.log("Grade: D");
    console.log("Very Enough");

} else {
    console.log("No Grade"); 
}